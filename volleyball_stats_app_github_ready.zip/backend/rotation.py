
def rotate(lineup):
    return lineup[-1:] + lineup[:-1]
